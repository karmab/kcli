#!/bin/bash
echo "i am the king of the bongo and i say $PARAM1 $PARAM2" > /tmp/prout
